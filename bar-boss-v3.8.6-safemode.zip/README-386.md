BAR BOSS v3.8.6 Safe Mode: ES5 JS, no CSS variables, visible UI. test-basic.html — проверка без JS.
